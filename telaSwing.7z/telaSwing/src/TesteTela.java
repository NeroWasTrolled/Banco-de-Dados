public class TesteTela {
    public static void main(String[] args){
        PrimeiraTela tela = new PrimeiraTela();
    }
}
