import javax.swing.*;

public class form2 {
    private JButton button1;
    private JButton button2;
    private JTextField textField1;
}
