﻿CREATE TABLE [dbo].[Table]
(
	[Id]      INT         IDENTITY (1, 1) NOT NULL,
    [nome]    NCHAR (115) NULL,
    [celular] NCHAR (25)  NULL,
    [cpf] NCHAR(30) NULL, 
    [cidade] NCHAR(30) NULL, 
    [data_nascimento] NCHAR(30) NULL, 
    PRIMARY KEY CLUSTERED ([Id] ASC)
)
