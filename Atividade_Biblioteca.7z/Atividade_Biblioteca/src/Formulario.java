import javax.swing.*;

public class Formulario {
    private JLabel lblNome;
    private JTextField txtNome;
    private JButton btnPesquisar;
    private JComboBox comboBox1;
}
