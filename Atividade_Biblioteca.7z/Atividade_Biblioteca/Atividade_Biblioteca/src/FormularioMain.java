import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class FormularioMain extends JFrame {
    private JPanel Main;
    private JTextField txtNome;
    private JButton btnPesquisar;
    private JLabel lblNome;
    private JTextField txtID;
    private JLabel lblID;
    private JButton alterarButton;
    private JButton novoButton;
    private JButton cadastrarButton;
    private JTextField txtExemplar;
    private JTextField txtAutor;
    private JTextField txtEdicao;
    private JTextField txtAno;
    private JTextField txtDisponibilidade;
    private JButton sairButton;
    private JLabel lblExemplar;
    private JLabel lblAutor;
    private JLabel lblEdicao;
    private JLabel lblAno;
    private JLabel lblDisponibilidade;
    private JTable tblCliente;
    private JButton excluirButton;

    private Connection conn;

    public FormularioMain() {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/biblioteca", "root", "");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Driver JDBC do MySQL não encontrado.");
            System.exit(1);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao conectar ao banco de dados.");
            System.exit(1);
        }

        cadastrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cadastrar();
            }
        });

        alterarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                alterar();
            }
        });

        excluirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                excluir();
            }
        });

        sairButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sair();
            }
        });
    }

    public void cadastrar() {
        String id = txtID.getText();
        String exemplar = txtExemplar.getText();
        String autor = txtAutor.getText();
        String edicao = txtEdicao.getText();
        String ano = txtAno.getText();
        String disponibilidade = txtDisponibilidade.getText();

        try {
            String sql = "INSERT INTO livro (id, exemplar, autor, edicao, ano, disponibilidade) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, id);
            stmt.setString(2, exemplar);
            stmt.setString(3, autor);
            stmt.setString(4, edicao);
            stmt.setString(5, ano);
            stmt.setString(6, disponibilidade);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Cadastro realizado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(this, "Não foi possível cadastrar.");
            }

            stmt.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao cadastrar: " + ex.getMessage());
        }
    }

    private void alterar() {
        String nome = txtNome.getText();
        String exemplar = txtExemplar.getText();
        String autor = txtAutor.getText();
        String edicao = txtEdicao.getText();
        String ano = txtAno.getText();
        String disponibilidade = txtDisponibilidade.getText();
        String id = txtID.getText();

        try {
            String sql = "UPDATE livro SET nome=?, exemplar=?, edicao=?, ano=?, disponibilidade=? WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, exemplar);
            stmt.setString(2, autor);
            stmt.setString(3, edicao);
            stmt.setString(4, ano);
            stmt.setString(5, disponibilidade);
            stmt.setString(6, id);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Registro alterado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(this, "Nenhum registro foi alterado.");
            }

            stmt.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao alterar registro: " + ex.getMessage());
        }
    }

    private void excluir() {
        String id = txtID.getText();

        try {
            String sql = "DELETE FROM livro WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, id);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Registro excluído com sucesso!");
            } else {
                JOptionPane.showMessageDialog(this, "Nenhum registro foi excluído.");
            }

            stmt.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao excluir registro: " + ex.getMessage());
        }
    }

    private void sair() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao fechar a conexão com o banco de dados: " + ex.getMessage());
        }

        System.exit(0);
    }

    public static void main(String[] args) {
        FormularioMain formulario = new FormularioMain();
        JPanel mainPanel = formulario.Main;
        JFrame frame = new JFrame("Formulário");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(mainPanel);
        frame.pack();
        frame.setVisible(true);
    }
}




